<?php
/*
Plugin Name: pfmirror
Plugin Script: pfmirror.php
Plugin URI: http://blog.forret.com/projects/wordpress-plugins/
Description: take the HTML body from an external page and show it in WP - use "pfmirror_showhtml([url])"
Version: 1.0
License: GPL
Author: Peter Forret
Author URI: http://blog.forret.com

=== CHANGES ===
- 2006-12-26 - v1.0 - first version
*/

// change next variable into "true" if it's not working
$pf_debugmode=false;

// ------------------
// pfmirror_showhtml will generate the (HTML) output
function pfmirror_showhtml($url) {
$pfmirror_html="<strong>(pfmirror: no URL given!)</strong>";
if(strlen($url)>12){
	$pfmirror_html = download_absolute($url); 
}
// content will be added when function 'pfmirror_showhtml()' is called
return $pfmirror_html;
}



function download_absolute($url) { 
	pf_debug("URL = " . $url);
	$user_agent="Mozilla/4.0 (compatible; MSIE 6.0)";
	$urlpart=parse_url($url);
	$root=$urlpart[scheme] . "://" ;
	if(strlen($urlpart[username])>0){
		$root=$root.$urlpart[username].":".$urlpart[password]."@";
	}
	$root=$root . $urlpart[host];
	if(strlen($urlpart[port])>0){
		$root=$root.":".$urlpart[port];
	}
	$path=$root;
	if(strlen($urlpart[path])>0){
		$path=$root . dirname($urlpart[path])."/";
	}
	pf_debug("root = " . $root);
	pf_debug("path = " . $path);

	$ch = curl_init(); 
	curl_setopt ($ch, CURLOPT_URL, $url); 
	curl_setopt ($ch, CURLOPT_USERAGENT, $user_agent); 
	curl_setopt ($ch, CURLOPT_HEADER, 0); 
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
	$result = curl_exec ($ch); 
	curl_close ($ch); 
	pf_debug (strlen($result) . " bytes retrieved via HTTP");
	// remove HTML comments, to make size smaller
	$result=ereg_replace('<!--[^>]*-->', "", $result);
	// remove excessive whitespace, to make size smaller
	$result=preg_replace("/\n[\t\s\n]*/", "\n", $result);
	// make sure absolute paths are left alone
	$result=preg_replace("/\s(href|src)=\"(http:|ftp:|https:)/i", " \${1}=\"---\${2}", $result);
	// change relative paths ("test.html")
	$result=preg_replace("/\s(href|src)=\"([^-\/])/i", " \${1}=\"" . $path . "\${2}", $result);
	// change relative rooted paths ("/users/test.html")
	$result=preg_replace("/\s(href|src)=\"\//i", " \${1}=\"" .$root . "/", $result);
	// restore absolute paths
	$result=preg_replace("/\s(href|src)=\"---/i", " \${1}=\"" , $result);
	pf_debug (strlen($result) . " bytes after correcting paths");

	$bodyandend = stristr($result,"<body"); 
	$positionendstartbodytag = strpos($bodyandend,">") + 1; 
	$temptofindposition=strtolower($bodyandend); 
	$positionendendbodytag=strpos($temptofindposition,"</body"); 
	$grabbedbody=substr($bodyandend, $positionendstartbodytag, $positionendendbodytag); 
	pf_debug (strlen($grabbedbody) . " bytes returned from [body][/body] ");
	return $grabbedbody; 
} 

function html_encode($var){	return htmlentities($var, ENT_QUOTES, 'UTF-8') ;}


function pf_debug($text){
	if($pf_debugmode){
	echo "<!-- [pfmirror] " . $text . " -->";
	}
}
?>